<h2>##Plugin Page Google para Wordpress 👨‍💻 </h2>
</br>

Page Google - Este plugin é gratuito e é um simples plugin para criar um simples custon post type para postar conteúdos de melhor engajamento no google.


 * Plugin Name: Page Google
 * Plugin URI: https://github.com/IlannahTaggyn
 * Description: Um simples plugin para criar um simples custom post type para postar conteúdos de melhor engajamento no Google.
 * Version: 0.0.1
 * Author: Ilannah Taggyn
 * License: GPLv2 or later
 * Text Domain: page-google


<h3>##Visualize um print da tela aqui </h3>
</br>


<div style="display: block; "><br>
  <img align="center" alt="Rafa-pic" width="100%" height="auto" style="border-radius:0px;" src="https://linkstudioart.com.br/wp-content/uploads/2023/05/pag-google.png">
</div>           
