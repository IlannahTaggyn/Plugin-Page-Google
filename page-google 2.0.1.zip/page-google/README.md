<h2>##Plugin Page Google para Wordpress 👨‍💻 </h2>
</br>

Page Google - Este plugin é gratuito e é um simples plugin para criar um simples custon post type para postar conteúdos de melhor engajamento no google.

 * Page Google
 *
 * Plugin Name: Page Google
 * Plugin URI: https://github.com/IlannahTaggyn
 * Description: Um simples plugin para criar um simples custom post type para postar conteúdos de melhor engajamento no Google.
 * Version: 2.0.1
 * Author: Ilannah Taggyn
 * License: GPLv2 or later
 * Text Domain: page-google
 *
 * Este plugin é gratuito e é um simples plugin para criar um simples custom post type para postar conteúdos de melhor engajamento no Google.
 *
 * Na versão 2.0.1 foi atualizado da versão 5.4 do PHP para o 7.4 do PHP e foi incluindo o registro das taxonomias personalizadas "page_google_category" e "page_google_tag" .
 


<h3>##Visualize um print da tela aqui </h3>
</br>


<div style="display: block; "><br>
  <img align="center" alt="Rafa-pic" width="100%" height="auto" style="border-radius:0px;" src="https://linkstudioart.com.br/wp-content/uploads/2023/05/pag-google.png">
</div>           
